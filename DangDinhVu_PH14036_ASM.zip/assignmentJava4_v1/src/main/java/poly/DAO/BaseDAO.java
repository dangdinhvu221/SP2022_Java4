package poly.DAO;

interface BaseDAO <Entity>{

}
